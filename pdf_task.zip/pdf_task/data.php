<?php
$con = mysqli_connect("localhost","root","","pdf_database");
$select_query = "SELECT * FROM `tbl_data`";
$query_run = mysqli_query($con,$select_query);


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container-fluid">
        <h1 class="text-center">DEMO DATA</h1> 
    <table class="table table-borderd table-dark mt-2">
  <thead>
    <tr>
      <th scope="col">USERNAME</th>
      <th scope="col">MESSAGE</th>
      <th scope="col">ID</th>

    </tr>
  </thead>
  <tbody>
  <?php while($row = mysqli_fetch_array($query_run)){?>
    <tr>
    <th scope="row"><?php echo $row['user_name'];?></th>
    <th><?php echo $row['message'];?></th>
    <th><?php echo $row['id'];?></th>
    </tr>
    <?php } ?>
  </tbody>
</table>
<div class="text-center">
<a href="mpdf_practice.php" class="btn btn-primary">Convert File into PDF</a>

</div>
    </div>

</body>
</html>