<?php
require_once __DIR__ . '/vendor/autoload.php';
$con = mysqli_connect("localhost","root","","pdf_database");
$select_query = "SELECT * FROM `tbl_data`";
$query_run = mysqli_query($con,$select_query);
$mpdf = new \Mpdf\Mpdf();
// while ($row = mysqli_fetch_array($query_run)) {
  $html = "    <div class='container-fluid'>
          <h1 class=text-center>DEMO DATA</h1> 
      <table class=table table-borderd table-dark mt-2>
    <thead>
      <tr>
        <th scope='col'>USERNAME</th>
        <th scope='col'>MESSAGE</th>
        <th scope='col'>ID</th>
  
      </tr>
    </thead>
    <tbody>
";
      while ($row = mysqli_fetch_array($query_run)) {
      $html .= "<tr>

      
      <td scope='row'>" . $row['user_name'] . "</td>
      <td>" . $row['message'] . "</td>
      <td>" . $row['id'] . "</td>

      </tr>
      
";
      }
 $html .= 
  "
    </tbody>
  </table>
      </div>";
      
    // }
    $mpdf->WriteHTML($html);
$mpdf->Output();
?>