<?php
   $con = mysqli_connect("localhost","root","","pdf_database");

   if(isset($_POST['submitbtn'])){
      $username = $_POST['username'];
      $message = $_POST['message'];
      $query = "INSERT INTO `tbl_data`(`user_name`, `message`) VALUES ('$username','$message')";
      $query_run = mysqli_query($con,$query);
      if($query_run){
         header('location:data.php');
      }
   }










?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="container-fluid" id="tabledata">
<h1 class="text-center">Form Data</h1>
   <form method="post">
   

  <div class="mb-3 mt-2">
    <label>Username</label>
    <input type="text" class="form-control" name="username"required>
  </div>

  <div class="mb-3">
    <label>Message</label>
    <input type="text" class="form-control" name="message" required> 
  </div>

  <input type="submit" class="btn btn-primary" value="Submit Data" name="submitbtn">


</form>
<a href="data.php" class="btn btn-primary mt-2">Show all Data</a>
</div>
</body>
</html>